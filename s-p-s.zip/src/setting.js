let settings = {
  db: {
  host     : "13.209.96.210",
  user     : "root",
  password : "qwe123",
  database : "spring-party"
  }
}


export default settings;