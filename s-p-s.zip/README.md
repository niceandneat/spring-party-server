# SpringParty Server


This repo contains source code for [SpringParty](https://github.com/agemor/spring-party) game server.
